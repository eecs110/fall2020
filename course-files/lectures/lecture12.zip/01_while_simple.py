# How do print this sentence over and over again? 
print('Hey there! Hope you\'re doing OK!')
