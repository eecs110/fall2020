# --------------------------------------------------------------------------------
# ## Example 4: Detecting data types
# --------------------------------------------------------------------------------

print(type(2.3))
print(type(100))
print(type('abcd'))
a = 5.7
print(type(a))
print(type(True))
print(type(0))

# these ones are more advanced examples. We'll be reviewing them
# in week 5.
print(type (123 == 124))
print(type(123 == 123 and 123 == 124))
