# Challenge: use a while loop to print all of the notes
# in the MARIO_NOTES list to the screen.

MARIO_NOTES = [
    76, 76, 76, 72, 76, 79, 67, 72, 67, 64, 69, 71,
    70, 69, 67, 76, 79, 81, 77, 79, 76, 72, 74, 71
]

length = len(MARIO_NOTES)
print(MARIO_NOTES[0])
print(MARIO_NOTES[1])
print(MARIO_NOTES[2])
print(MARIO_NOTES[3])
