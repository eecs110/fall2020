# Here is some alternative syntax for importing modules:
from my_module import  get_area, get_perimeter, get_hypotenuse


print('Area:', get_area(32, 23))
print('Perimeter:', get_perimeter(32, 23))
print('Hypotenuse:', get_hypotenuse(32, 23))