'''
INSTRUCTIONS: Update this function as follows:
If red is turned on, make the background red.
If yellow is turned on, make the background yellow.
If blue is turned on, make the background blue.
If red and yellow are both turned on, make the background orange.
If red and blue are turned on, make the background purple.
If yellow and blue are turned on, make the background green.
If everything is turned on, then make the background black.
'''

def get_color(red_switch:bool, green_switch:bool, blue_switch:bool):
    '''
    Given the following switches, this function will return the
    correct color
    '''

    