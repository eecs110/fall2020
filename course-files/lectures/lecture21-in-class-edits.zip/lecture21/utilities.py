
def get_file_path(file_name, subdirectory=None):
    import os
    import sys
    dir_path = os.path.dirname(sys.argv[0])
    if subdirectory:
        return os.path.join(dir_path, subdirectory, file_name)
    else:
        return os.path.join(dir_path, file_name)

import urllib.request
import json
import ssl

def search_for_tracks(search_term:str):
    # encode it for a web request:
    search_term = search_term.replace(' ', '%20')
    
    # create query url:
    url = 'https://www.apitutor.org/spotify/simple/v1/search?type=track&q='
    url += search_term

    # retrieve the data:
    context = ssl._create_unverified_context()
    response = urllib.request.urlopen(url, context=context)
    tracks = json.loads(response.read().decode())
    return tracks