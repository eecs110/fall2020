track = {
    "id": "5IVuqXILoxVWvWEPm82Jxr",
    "name": "Crazy In Love (feat. Jay-Z)",
    "preview_url": "https://p.scdn.co/mp3-preview/ce8ace0ec425840416be78db07cf50dd331eed4f?cid=9697a3a271d24deea38f8b7fbfa0e13c",
    "album": {
        "id": "6oxVabMIqCMJRYN1GqR3Vf",
        "name": "Dangerously In Love",
        "image_url": "https://i.scdn.co/image/ab67616d0000b27345680a4a57c97894490a01c1"
    },
    "artist": {
        "id": "6vWDO969PvNqNYHIOW5v0m",
        "name": "Beyoncé"
    }
}

# print the album name:
# first access the data stored at the "album" key
# and then access the data's "name" key:
album = track.get('albfdsfdsum')
print(album)

# album_name = album.get('name') 
# print(album_name)

# # option 2:
# print(track.get('album').get('name'))

