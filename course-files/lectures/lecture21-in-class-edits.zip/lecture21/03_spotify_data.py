import utilities


search_term = input('What artist would you like to listen to? ')
tracks = utilities.search_for_tracks(search_term)

for track in tracks:
    print(track.get('name'), '-', track.get('artist').get('name'))