# What will the output of this program be?
result = 2 ** 2 * 3 // 5 + 2
print(result)
print(type(result))  # int