# Consider the following program:
# What value is stored in the variable "result"?
# What data type is the value stored in the variable "result"?

name = 'Sapo'
result = 'hello ' + ' there, ' + 'name'

print(result)
# if you ever want to know what type of data you have, use the built-in type() function:
print(type(result))  